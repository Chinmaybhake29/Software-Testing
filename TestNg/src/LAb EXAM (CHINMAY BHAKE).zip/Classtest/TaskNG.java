package Classtest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class TaskNG {
	public static WebDriver wd=new ChromeDriver();
	
//	
//  @Test
//  public void f() {
//	  wd.findElement(By.)
//  }
//  @BeforeTest
//  public void beforeTest() {
//	  wd.get("https://automationexercise.com/login");
//
//  }
//
//  @AfterTest
//  public void afterTest() {
//  }

}
